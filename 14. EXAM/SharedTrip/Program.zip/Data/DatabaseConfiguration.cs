﻿namespace SharedTrip
{
    public class DatabaseConfiguration
    {
        public const string ConnectionString =
            @"Server=.\Applications;Database=SharedTrip;Trusted_Connection=True;Integrated Security=True;";
    }
}